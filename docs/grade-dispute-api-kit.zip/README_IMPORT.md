# Thunder Client Import Guide

Files in this folder:
- `thunder_collection.json`
- `thunder_environment.json`
- `API_CONTRACT.md`

## Import in VS Code Thunder Client
1. Open Thunder Client sidebar.
2. Click Settings (gear icon).
3. Choose `Import`.
4. Import `thunder_environment.json` first.
5. Import `thunder_collection.json` next.
6. Select environment `Grade Dispute Local`.

## Quick variables to update
- `base_url`
- `student_identifier`
- `lecturer_identifier`
- `admin_identifier`
- `dispute_id`
- `notification_id`

## Notes
- Protected routes require `X-User-Identifier` header.
- The collection already includes this header where needed.
- For live testing, run: `php artisan serve`
